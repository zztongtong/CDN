var data={
  "haveFan":false,
  "star":0,
  "bId":"1394562225057959936",
  "currentUserId": "111",
  "userInfo":{},
  "blog":{
      "title":"这里是文章标题",
      "text":"这里是你的文章内容",
      "tagNames": [ "标签1", "标签2" ],
      "viewNum": 1457,
      "createTimeStr": "2020-03-27",
      "createUserName":"作者名称",
      "preBlogId": "1364739476525551616",
      "preBlogTitle": "上一篇博客标题",
      "nextBlogId": "1364739476525551616",
      "nextBlogTitle": "下一篇博客标题"
  },
  "tagTwos":[],  
  "latestBlogs": [
    {
      "blogIdStr": "1394562225057959936",
      "title": "最新博客1"
    },
    {
      "blogIdStr": "1394562225057959936",
      "title": "最新博客2"
    },
    {
      "blogIdStr": "1394562225057959936",
      "title": "最新博客3"
    }
  ],
  "ansList": []
}